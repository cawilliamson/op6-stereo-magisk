Changelog:

v1 - Initial Release
v2 - Fixed the earpiece not working throughout the system
v3 - Fixed the earpiece not working during call
v4 - Converted to Unity module and added AML support
